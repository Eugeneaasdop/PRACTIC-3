﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace ПР_3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            char[,] alfrus = {     {'А', 'Б', 'В', 'Г', 'Д', 'Е', 'Ё'},
                                   {'Ж', 'З', 'И', 'Й', 'К', 'Л', 'М'},
                                   {'Н', 'О', 'П', 'Р', 'С', 'Т', 'У'},
                                   {'Ф', 'Х', 'Ц', 'Ч', 'Ш', 'Щ', 'Ъ'},
                                   {'Ы', 'Ь', 'Э', 'Ю', 'Я', '0', '1'},
                                   { '2','3', '4', '5', '6', '7', '8'},
                                   {'9', ' ', ',', '.', '!', '?', ';'}
                               };


            Console.WriteLine("Введите сообщение рускими буквами для шифровки: ");
            string message = Console.ReadLine();
            string new_message = "";



            for (int i = 0; i < message.Length; i++)
            {
                for (int j = 0; j < alfrus.GetLength(0); j++)
                    for (int k = 0; k < alfrus.GetLength(1); k++)
                        if (Char.ToLower(alfrus[j, k]) == message[i] || Char.ToUpper(alfrus[j, k]) == message[i])
                        {
                            new_message += (Convert.ToString(j) + Convert.ToString(k));
                            break;
                        }

            }
            Console.WriteLine(new_message);
            StreamWriter streamWriter = new StreamWriter("file.txt", false, Encoding.UTF8);
            streamWriter.WriteLine(new_message);
            streamWriter.Close();
            StreamReader streamReader = new StreamReader("file.txt", Encoding.UTF8);
            string stroka = "";
            stroka = streamReader.ReadLine();
            streamReader.Close();
            Console.WriteLine("Код из файла:" + stroka);
            Console.WriteLine("Расшифрованное сообщение из файла:");
            string new_message1 = "";
            for (int a = 0; a < stroka.Length; a += 2)
            {
                new_message1 += alfrus[Convert.ToInt32(stroka[a].ToString()), Convert.ToInt32(stroka[a + 1].ToString())];
            }
            Console.WriteLine(new_message1);
            Console.ReadKey();
        }
    }
}
